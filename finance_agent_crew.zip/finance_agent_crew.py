import os
from crewai import Agent, Task, Crew, Process
from langchain_openai import ChatOpenAI
from langchain_community.tools import DuckDuckGoSearchRun
from langchain.tools import tool
import yfinance as yf

# ==========================================
# 0. 环境与大模型配置 (Environment & LLM Setup)
# ==========================================
# 填入申请到的 API Key，这里支持各类兼容 OpenAI 格式的模型（如 GPT-4, Claude 等）
os.environ["OPENAI_API_KEY"] = "YOUR_API_KEY_HERE"
# os.environ["OPENAI_API_BASE"] = "YOUR_API_BASE_URL" # 如果是第三方中转或内测接口

# 实例化大模型，设置较高的温度值以保证研报的生成质量和推理深度
llm = ChatOpenAI(model="gpt-4-turbo-preview", temperature=0.3)

# ==========================================
# 1. 定义外部工具 (Define Tools for Agents)
# ==========================================
search_tool = DuckDuckGoSearchRun()

@tool("Stock Data Fetcher")
def stock_data_tool(ticker: str) -> str:
    """Useful to fetch live stock price, market cap, and basic financial metrics."""
    try:
        stock = yf.Ticker(ticker)
        info = stock.info
        return f"Ticker: {ticker}, Price: {info.get('currentPrice')}, Market Cap: {info.get('marketCap')}, PE Ratio: {info.get('forwardPE')}"
    except Exception as e:
        return f"Error fetching data for {ticker}: {e}"

# ==========================================
# 2. 定义 Agent 角色 (Define Multi-Agents)
# ==========================================

# 规划与研究 Agent (搜集异构数据)
researcher_agent = Agent(
    role='资深高级行业研究员',
    goal='针对目标公司及其所在行业，进行深度的异构数据检索（包括财报、新闻、舆情等）',
    backstory='你是一名在华尔街拥有10年经验的顶级数据挖掘专家，擅长从海量互联网噪音中提取有价值的财务和业务数据。',
    verbose=True,
    allow_delegation=False,
    tools=[search_tool, stock_data_tool],
    llm=llm
)

# 财务与商业分析 Agent (长链推理与逻辑拆解)
analyst_agent = Agent(
    role='首席财务与战略分析师',
    goal='基于研究员收集的海量原始数据，进行长链逻辑推理，提炼出公司的核心护城河、风险点及财务健康度。',
    backstory='你以严密的逻辑推理和敏锐的商业嗅觉著称。你从不盲目相信数据，而是通过交叉对比找出隐藏的商业逻辑。',
    verbose=True,
    allow_delegation=True, # 允许其将问题打回给研究员重新搜索
    llm=llm
)

# 审查与合规 Agent (Fact-check)
critic_agent = Agent(
    role='合规风控与数据审查官',
    goal='对分析师输出的研报初稿进行严格的“数据幻觉”审查和合规性校验，确保所有结论都有事实支撑。',
    backstory='你是以严谨苛刻出名的风控官，你的工作是防止研报中出现任何虚假捏造的数据或过于主观的猜测。',
    verbose=True,
    allow_delegation=False,
    llm=llm
)

# ==========================================
# 3. 定义任务链 (Define Tasks Flow)
# ==========================================
company_name = "NVIDIA (NVDA)"

task1_research = Task(
    description=f'全面检索 {company_name} 最新的季度财报亮点、近期核心产品发布（如 Blackwell 架构）、以及当前实时股价数据。形成结构化的数据简报。',
    expected_output='一份包含实时财务指标、近期新闻事件和市场舆情的结构化数据列表。',
    agent=researcher_agent
)

task2_analysis = Task(
    description=f'基于研究员提供的数据，深度分析 {company_name} 在 AI 芯片市场的竞争优势（护城河）、潜在的供应链风险以及未来 12 个月的估值逻辑。',
    expected_output='一篇深度逻辑分析报告，包含：1. 护城河分析 2. 风险提示 3. 财务与估值预期。',
    agent=analyst_agent
)

task3_review = Task(
    description='严格审查分析师的研报初稿。检查其中提到的财务数据是否与研究员提供的数据一致。修正过度夸大的词汇，并输出最终的专业级商业研报。',
    expected_output='排版精美的 markdown 格式最终商业研报，确保 100% 数据准确无幻觉。',
    agent=critic_agent
)

# ==========================================
# 4. 组建 Crew 集群并启动执行 (Orchestrate & Execute)
# ==========================================
financial_crew = Crew(
    agents=[researcher_agent, analyst_agent, critic_agent],
    tasks=[task1_research, task2_analysis, task3_review],
    process=Process.sequential, # 采用顺序工作流（模拟长链推理过程）
    verbose=True
)

if __name__ == "__main__":
    print(f"🚀 [System Log] 开始启动多 Agent 协同投资分析工作流...")
    print(f"🎯 [Target] 目标公司: {company_name}\n")
    
    # Kickoff 启动长链推理
    final_report = financial_crew.kickoff()
    
    print("\n==============================================")
    print("✅ [System Log] 分析完成！以下为多 Agent 协同生成的最终研报：")
    print("==============================================")
    print(final_report)